from fastapi import FastAPI, Query
from services.calendar_auth import get_today_events
from services.commute import get_commute_info
from services.uber import generate_uber_link
from fastapi.middleware.cors import CORSMiddleware



app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For dev; restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/next-meeting-commute")
async def next_meeting_commute(home_address: str = Query(...)):
    print("Received home_address:", home_address)
    events = await get_today_events()
    next_event = next((e for e in events if e.get("location")), None)
    print("Next event:", next_event)
    if not next_event:
        return {"message": "No upcoming events with locations found."}

    commute = await get_commute_info(destination=next_event["location"], origin=home_address)
    print("Commute:", commute)

    print(f"Pickup: {home_address}")
    print(f"Destination: {next_event['location']}")
    uber_link = generate_uber_link(destination=next_event["location"], pickup=home_address)
    print("Uber link:", uber_link)

    return {
        "next_event": next_event,
        "commute_info": commute,
        "uber_link": uber_link
    }
