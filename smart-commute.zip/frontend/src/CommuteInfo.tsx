import React, { useState } from "react";
import axios from "axios";

interface Event {
  location?: string;
  summary?: string;
  [key: string]: any;
}

interface CommuteInfo {
  duration?: string;
  traffic?: string;
  summary?: string;
  [key: string]: any;
}

interface ApiResponse {
  next_event: Event | null;
  commute_info: CommuteInfo | null;
  uber_link: string;
}

function CommuteInfo() {
  const [homeAddress, setHomeAddress] = useState("");
  const [destinationAddress, setDestinationAddress] = useState("");
  const [result, setResult] = useState<ApiResponse | null>(null);
  const [error, setError] = useState("");

  const handleFetch = async () => {
    if (!homeAddress) {
      setError("Please enter your home address");
      return;
    }
    setError("");
    try {
      const response = await axios.get<ApiResponse>(
        "http://127.0.0.1:9000/next-meeting-commute",
        { params: {  home_address: homeAddress,
          ...(destinationAddress && { destination: destinationAddress }), } }
      );
      setResult(response.data);
    } catch (err) {
      setError("Failed to fetch commute info");
      console.error(err);
    }
  };

  return (
     <div>
      <h2>Smart Commute Planner</h2>

      <div style={{ marginBottom: "10px" }}>
        <input
          type="text"
          placeholder="Enter your home address"
          value={homeAddress}
          onChange={(e) => setHomeAddress(e.target.value)}
          style={{ width: "300px", marginRight: "10px" }}
        />
      </div>

      <div style={{ marginBottom: "10px" }}>
        <input
          type="text"
          placeholder="Optional: Enter destination address"
          value={destinationAddress}
          onChange={(e) => setDestinationAddress(e.target.value)}
          style={{ width: "300px", marginRight: "10px" }}
        />
      </div>

      <button onClick={handleFetch}>Get Commute Info</button>

      {error && <p style={{ color: "red" }}>{error}</p>}
      {result && (
  <div style={{ marginTop: "20px" }}>
    <h3>Next Meeting</h3>
    <p>
      <strong>Location:</strong> {result.next_event?.location || "N/A"}
    </p>
    <p>
      <strong>Summary:</strong> {result.next_event?.summary || "N/A"}
    </p>

    <h3>Commute Info</h3>
    <p>
      <strong>Duration:</strong> {result.commute_info?.duration || "N/A"}
    </p>
    <p>
      <strong>Traffic:</strong> {result.commute_info?.traffic || "N/A"}
    </p>
    <p>
      <strong>Route Summary:</strong> {result.commute_info?.summary || "N/A"}
    </p>

    <h3>Uber Ride</h3>
    {result.uber_link ? (
      <a href={result.uber_link} target="_blank" rel="noreferrer">
        Book Uber Ride
      </a>
    ) : (
      <p>No Uber link available.</p>
    )}
  </div>
)}
    </div>
  );
}

export default CommuteInfo;
