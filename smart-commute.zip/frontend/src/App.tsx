
import './App.css'
import React from "react";
import CommuteInfo from "./CommuteInfo";

function App() {
  return (
    <div className="App">
      <CommuteInfo />
    </div>
  );
}

export default App
