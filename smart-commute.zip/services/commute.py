import os
from dotenv import load_dotenv
import httpx

load_dotenv()
GOOGLE_MAPS_KEY = os.getenv("GOOGLE_MAPS_API_KEY")

async def get_commute_info(destination: str, origin: str):
    endpoint = "https://maps.googleapis.com/maps/api/directions/json"
    params = {
        "origin": origin,
        "destination": destination,
        "key": GOOGLE_MAPS_KEY,
        
    }

    async with httpx.AsyncClient() as client:
        res = await client.get(endpoint, params=params)
        if res.status_code == 200:
            data = res.json()
            if data['routes']:
                leg = data['routes'][0]['legs'][0]
                return {
                    "duration": leg['duration']['text'],
                    "traffic": leg.get('duration_in_traffic', {}).get('text', 'N/A'),
                    "summary": data['routes'][0].get('summary'),
                    "start_location": leg['start_location'],  # coordinates
                    "end_location": leg['end_location']       # coordinates
                }
    return {}
