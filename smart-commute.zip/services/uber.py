from urllib.parse import urlencode

def generate_uber_link(destination: str, pickup: str):
    params = {
        "action": "setPickup",
        "pickup[formatted_address]": pickup,
        "dropoff[formatted_address]": destination
    }
    return f"https://m.uber.com/ul/?{urlencode(params)}"
